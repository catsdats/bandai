#include <stdio.h>
int main(void)
{
    float f = 0.0;
    f = f + 10.1;
    f = f + 10.1;
    printf("f�̒l�� %f\n", f);
}