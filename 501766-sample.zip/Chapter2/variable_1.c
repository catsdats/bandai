#include <stdio.h>
int main(void)
{
    int life = 500;
    int score = 0;
    int i = -1;
    char c = 'A';
    printf("life�̒l��%d\n", life);
    printf("score�̒l��%d\n", score);
    printf("i�̒l��%d\n", i);
    printf("c�̒l��%c\n", c);
}
