#include <stdio.h>
int main(void)
{
    int i1 = 10;
    int i2 = 4;
    double d1 = i1 / i2;
    double d2 = (double)i1 / (double)i2;
    printf("i1�̒l�� %d\n", i1);
    printf("i2�̒l�� %d\n", i2);
    printf("d1�̒l�� %f\n", d1);
    printf("d2�̒l�� %f\n", d2);
}