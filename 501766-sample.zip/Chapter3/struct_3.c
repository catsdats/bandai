#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
struct CHARACTER
{
    char name[7];
    int life;
    int strength;
    int defense;
};

int main(void)
{
    struct CHARACTER player;
    strcpy(player.name, "�}�[�Y");
    player.life = 1000;
    player.strength = 500;
    player.defense = 300;
    printf("���O %s\n", player.name);
    printf("�̗� %d\n", player.life);
    printf("�r�� %d\n", player.strength);
    printf("�h��� %d\n", player.defense);
}